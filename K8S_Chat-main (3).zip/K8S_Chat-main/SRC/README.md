# 1.npm install
# 2.npm run dev
