const config = {
  maxSizeUploadAvatar: 1048576 // bytes
}

export default config
