export interface Category {
  _id: string
  name: string
  icon:string
}
interface testType {
  name: string
  age: number
}
