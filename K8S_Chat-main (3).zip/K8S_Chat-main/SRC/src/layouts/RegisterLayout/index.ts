import RegisterLayout from './RegisterLayout'

export default RegisterLayout
