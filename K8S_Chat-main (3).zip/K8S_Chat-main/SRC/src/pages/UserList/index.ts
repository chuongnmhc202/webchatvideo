import UserList from './UserList'

export default UserList
