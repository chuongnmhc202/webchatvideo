import UserComponent from './User'

export default UserComponent
