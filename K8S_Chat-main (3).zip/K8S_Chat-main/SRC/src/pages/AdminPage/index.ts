import AdminPage from './AdminPage'
export default AdminPage
