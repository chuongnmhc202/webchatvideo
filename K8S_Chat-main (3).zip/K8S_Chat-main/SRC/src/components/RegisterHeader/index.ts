import RegisterHeader from './RegisterHeader'

export default RegisterHeader
